$(document).ready(function() {
    $('#data').DataTable({
    	"lengthMenu": [[20, 50, 100, 150], [25, 50, 100, 150]]
    });
} );